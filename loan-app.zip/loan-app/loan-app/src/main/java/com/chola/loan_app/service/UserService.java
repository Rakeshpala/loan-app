package com.chola.loan_app.service;

import com.chola.loan_app.LoanAppApplication;
import com.chola.loan_app.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;
import  java.util.Calendar;

@Service
public class UserService {



    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[a-zA-Z0-9_.+-]{4,}@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$");


    //EMAIL VALIDATION
    public boolean validateEmail(String email){
        if (email.toLowerCase().contains("reply")) {
            return false;
        } else return EMAIL_PATTERN.matcher(email).matches();
    }

    //PAN MOCKING
   public String mockPanVerification(String pan_number){
        if("GPGME2022D".equalsIgnoreCase(pan_number))
        {
            return "RAKESH PALA";
        }
        else if( "ABCDE2022D".equalsIgnoreCase(pan_number))
        {
            return "PRIYA SRINIVAS";
        }
        return "INVALID_PAN";
   }

   //PAN VALIDATION
   public boolean isPanMatching(String first_name,String last_name, String pan_number){
               String enteredName=(first_name +" "+ last_name).trim().toLowerCase();
               String panName = mockPanVerification(pan_number).toLowerCase();

               if("INVALID_PAN".equalsIgnoreCase(panName))
               {
                   return false;
               }
               return enteredName.equals(panName);
   }
   //AGE VALIDATION
    public boolean validateAge(String dobInput){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        LocalDate currentYear = LocalDate.now();

        LocalDate dob = LocalDate.parse(dobInput,formatter);

        int age = Period.between(dob,currentYear).getYears();

        return age>=21 && age <=60;


    }


}
