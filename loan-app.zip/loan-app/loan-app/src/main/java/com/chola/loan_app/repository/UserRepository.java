package com.chola.loan_app.repository;

import com.chola.loan_app.model.CreateApplication;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface UserRepository extends MongoRepository<CreateApplication, String> {


}
