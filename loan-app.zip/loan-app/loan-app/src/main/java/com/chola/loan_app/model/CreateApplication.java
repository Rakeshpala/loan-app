package com.chola.loan_app.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("createApplication")
public class CreateApplication {

    @Id
    private String id;
    private  String first_name;
    private String last_name ;
    private double mobile_number;
    private String date_of_birth;
    private String gender;
    private String personal_email_id;
    private String pan_number;
    private String aadhaar;

    private String customer_consent;

    private String qualification;
    private String employment_type;
    private String company_name;
    private String income_type;
    private String residential_status;
    private int pin_code;

    public CreateApplication(String gender, String id, String first_name, String last_name, double mobile_number,
                             String date_of_birth, String personal_email_id, String pan_number, String aadhaar,
                             String customer_consent, String qualification, String employment_type,
                             String company_name, String income_type, String residential_status, int pin_code) {
        this.gender = gender;
        this.id = id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.mobile_number = mobile_number;
        this.date_of_birth = date_of_birth;
        this.personal_email_id = personal_email_id;
        this.pan_number = pan_number;
        this.aadhaar = aadhaar;
        this.customer_consent = customer_consent;
        this.qualification = qualification;
        this.employment_type = employment_type;
        this.company_name = company_name;
        this.income_type = income_type;
        this.residential_status = residential_status;
        this.pin_code = pin_code;
    }

    public String getDate_of_birth() {
        return date_of_birth;
    }

    public void setDate_of_birth(String date_of_birth) {
        this.date_of_birth = date_of_birth;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public double getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(double mobile_number) {
        this.mobile_number = mobile_number;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPersonal_email_id() {
        return personal_email_id;
    }

    public void setPersonal_email_id(String personal_email_id) {
        this.personal_email_id = personal_email_id;
    }

    public String getPan_number() {
        return pan_number;
    }

    public void setPan_number(String pan_number) {
        this.pan_number = pan_number;
    }

    public String getAadhaar() {
        return aadhaar;
    }

    public void setAadhaar(String aadhaar) {
        this.aadhaar = aadhaar;
    }

    public String getCustomer_consent() {
        return customer_consent;
    }

    public void setCustomer_consent(String customer_consent) {
        this.customer_consent = customer_consent;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getEmployment_type() {
        return employment_type;
    }

    public void setEmployment_type(String employment_type) {
        this.employment_type = employment_type;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public String getIncome_type() {
        return income_type;
    }

    public void setIncome_type(String income_type) {
        this.income_type = income_type;
    }

    public String getResidential_status() {
        return residential_status;
    }

    public void setResidential_status(String residential_status) {
        this.residential_status = residential_status;
    }

    public int getPin_code() {
        return pin_code;
    }

    public void setPin_code(int pin_code) {
        this.pin_code = pin_code;
    }

    




}
