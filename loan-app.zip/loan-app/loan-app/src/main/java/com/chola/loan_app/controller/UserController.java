package com.chola.loan_app.controller;


import com.chola.loan_app.model.CreateApplication;
import com.chola.loan_app.repository.UserRepository;
import com.chola.loan_app.service.UserService;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.regex.Pattern;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/createApplication")
public class UserController {


    public UserRepository userRepository;
    public UserService service;
    @Autowired
    public UserController(UserRepository userRepository,UserService service)
    {
        this.userRepository=userRepository;
        this.service=service;
    }

    @PostMapping("/add")
    public ResponseEntity<?> addUser(@RequestBody CreateApplication user){
        boolean isValidEmail= service.validateEmail(user.getPersonal_email_id());
        boolean isValidPan = service.isPanMatching(user.getFirst_name(),user.getLast_name(),user.getPan_number());
        boolean isValidAge=service.validateAge(user.getDate_of_birth());
        if(isValidEmail && isValidPan && isValidAge) {
            CreateApplication savedUser = userRepository.save(user);
            return ResponseEntity.ok(Map.of(
                    "Status","Success" ,
                     "Message","Application Saved Successfully"
            ));
        }
        else {
               return ResponseEntity.badRequest().body("Invalid Email ID OR INVALID PAN OR NAME MISMATCH OR INVALID AGE");
        }

    }

}
